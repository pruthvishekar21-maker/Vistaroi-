import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Pages
import App from "./App";
import Login from "./Login";
import Signup from "./Signup";
import Dashboard from "./Dashboard";
import Privacy from "./Privacy";
import Terms from "./Terms";
import Refund from "./Refund";
import contact from "/contact"

// Firebase auth check
import { auth } from "./auth";
import { onAuthStateChanged } from "firebase/auth";

function ProtectedRoute({ children }: { children: JSX.Element }) {
  const [user, setUser] = React.useState<any>(undefined);

  React.useEffect(() => {
    onAuthStateChanged(auth, (u) => setUser(u));
  }, []);

  if (user === undefined) return <p style={{ color: "white" }}>Loading...</p>;

  return user ? children : <Login />;
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />

      {/* Legal Pages */}
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/refund" element={<Refund />} />
      <Route path="/contact" element={<Contact />} />
    </Routes>
  </BrowserRouter>
);