import { Link } from "react-router-dom";

export default function Landing() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-black to-neutral-900 text-white">

      {/* HERO */}
      <section className="px-6 pt-32 pb-24 text-center">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-yellow-400 bg-clip-text text-transparent">
          See Beyond Data. Grow Beyond Limits.
        </h1>

        <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
          Vistaroi helps businesses visualize performance, uncover hidden growth
          potential, and optimize ROI — powered by AI.
        </p>

        <div className="mt-8 flex justify-center gap-4">
          <Link
            to="/login"
            className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 transition"
          >
            Start Free
          </Link>

          <a
            href="#features"
            className="px-6 py-3 rounded-xl border border-gray-500 hover:bg-white/10 transition"
          >
            See How It Works
          </a>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="px-6 py-24">
        <h2 className="text-3xl font-semibold text-center mb-16">
          Powering your business with intelligent insights
        </h2>

        <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto">
          {[
            "AI Strategizer",
            "ROI Visualizer",
            "Lead Heatmap",
            "Competitor Analysis",
            "Profit Predictor",
            "Smart Recommendations",
          ].map((feature) => (
            <div
              key={feature}
              className="p-6 rounded-2xl bg-white/5 backdrop-blur-lg border border-white/10 hover:scale-[1.03] transition"
            >
              <h3 className="text-xl font-semibold mb-2">{feature}</h3>
              <p className="text-gray-400">
                AI-powered tool designed to boost your business performance automatically.
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING PREVIEW */}
      <section className="px-6 pb-24">
        <h2 className="text-3xl font-semibold text-center mb-10">
          Pricing Plans
        </h2>

        <div className="flex justify-center gap-8">
          {["Starter", "Growth", "Elite"].map((p) => (
            <div
              key={p}
              className="w-64 p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-lg"
            >
              <h3 className="text-xl font-semibold mb-2">{p}</h3>
              <p className="text-gray-400 text-sm">
                Smart tools for businesses at every stage.
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-8">
          <Link
            to="/pricing"
            className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 transition"
          >
            View Full Pricing
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="px-6 py-10 text-center text-gray-400 text-sm">
        <Link to="/policy" className="mx-4 hover:text-white">Privacy</Link>
        <Link to="/terms" className="mx-4 hover:text-white">Terms</Link>
        <Link to="/refund" className="mx-4 hover:text-white">Refund Policy</Link>

        <p className="mt-4">© 2025 Vistaroi. All rights reserved.</p>
      </footer>
    </div>
  );
}