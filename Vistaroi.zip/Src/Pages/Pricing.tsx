import { Link } from "react-router-dom";

export default function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "$19/mo",
      tagline: "Perfect for solo entrepreneurs.",
      features: [
        "AI Business Strategizer (basic)",
        "Core ROI dashboard",
        "City-level demand insights",
        "Manual optimization tips",
        "Track 1 competitor",
        "Weekly reports",
        "Google + Meta integration",
        "AI Chat Support",
      ],
    },
    {
      name: "Growth",
      price: "$39/mo",
      tagline: "For growing startups.",
      features: [
        "Everything in Starter",
        "Advanced AI Strategizer",
        "Trend visualizations",
        "Interactive heatmaps",
        "AI ad optimization",
        "Track 5 competitors",
        "Lead scoring",
        "Exportable reports",
        "Up to 5 users",
        "Shopify + HubSpot integration",
      ],
    },
    {
      name: "Elite",
      price: "$79/mo",
      tagline: "For agencies and scaling businesses.",
      features: [
        "Everything in Growth",
        "Predictive AI strategist",
        "Forecasting dashboard",
        "AI-driven location predictions",
        "Auto ad optimization",
        "Track 10+ competitors",
        "Lead intent prediction",
        "Auto-scheduled reports",
        "15 users",
        "API + Zapier",
        "White-label branding",
        "24/7 AI priority support",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white px-6 py-20">
      <h1 className="text-center text-4xl font-bold mb-12">Pricing Plans</h1>

      <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto">
        {plans.map((p) => (
          <div
            key={p.name}
            className="p-8 bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10"
          >
            <h2 className="text-2xl font-semibold">{p.name}</h2>
            <p className="text-purple-400 text-xl mt-2">{p.price}</p>
            <p className="text-gray-400 mt-2">{p.tagline}</p>

            <ul className="mt-6 space-y-2 text-gray-300">
              {p.features.map((f, i) => (
                <li key={i}>• {f}</li>
              ))}
            </ul>

            <Link
              to="/login"
              className="block mt-8 text-center px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 transition"
            >
              Start Free Trial
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}