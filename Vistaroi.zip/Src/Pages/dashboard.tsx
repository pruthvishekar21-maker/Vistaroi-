import { useEffect, useState } from "react";
import Chatbot from "../Components/Chatbot";

export default function Dashboard() {
  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ color: "white" }}>Dashboard</h1>
      <Chatbot />
    </div>
  );
}
export default function Dashboard() {
  const quotes = [
    "Data is the new strategy.",
    "Small insights create big profits.",
    "Let your numbers speak success.",
  ];

  const [quote, setQuote] = useState(quotes[0]);
  const [aiInsight, setInsight] = useState("Loading...");

  useEffect(() => {
    setInterval(() => {
      setQuote(quotes[Math.floor(Math.random() * quotes.length)]);
    }, 5000);

    generateAIResponse("Give me a business insight based on generic data.", [])
      .then(setInsight);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
      <p className="text-gray-400 mb-10">{quote}</p>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="p-6 bg-white/5 rounded-xl backdrop-blur-xl border border-white/10">
          <h2 className="text-xl font-semibold mb-2">AI Insight</h2>
          <p className="text-gray-300">{aiInsight}</p>
        </div>

        <div className="p-6 bg-white/5 rounded-xl backdrop-blur-xl border border-white/10">
          <h2 className="text-xl font-semibold">ROI Overview</h2>
          <p className="text-gray-400">Charts will appear here.</p>
        </div>

        <div className="p-6 bg-white/5 rounded-xl backdrop-blur-xl border border-white/10">
          <h2 className="text-xl font-semibold">Lead Heatmap</h2>
          <p className="text-gray-400">Map showing top-performing regions.</p>
        </div>
      </div>
    </div>
  );
}