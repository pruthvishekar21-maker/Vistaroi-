import React from "react";

export default function Contact() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-zinc-900 text-white px-6 py-20 flex justify-center">
      <div className="w-full max-w-3xl bg-white/5 backdrop-blur-xl p-10 rounded-2xl shadow-xl border border-white/10">

        {/* Header */}
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-yellow-400 bg-clip-text text-transparent text-center mb-6">
          Contact Vistaroi
        </h1>

        <p className="text-zinc-300 text-center mb-10">
          Have questions? Need help? We're here to support your growth.
        </p>

        {/* Contact Info */}
        <div className="space-y-4">
          <div className="bg-white/5 p-5 rounded-xl border border-white/10">
            <h2 className="text-xl font-semibold text-purple-300">Email</h2>
            <p className="text-zinc-300">pruthvi@vistaroi.com</p>
          </div>

          <div className="bg-white/5 p-5 rounded-xl border border-white/10">
            <h2 className="text-xl font-semibold text-purple-300">Phone</h2>
            <p className="text-zinc-300">+91 82967 11501</p>
          </div>

          <div className="bg-white/5 p-5 rounded-xl border border-white/10">
            <h2 className="text-xl font-semibold text-purple-300">Location</h2>
            <p className="text-zinc-300">Bengaluru, Karnataka, India</p>
          </div>
        </div>

        {/* Footer note */}
        <p className="text-center text-sm text-zinc-500 mt-10">
          We respond within 24 hours.
        </p>
      </div>
    </div>
  );
}