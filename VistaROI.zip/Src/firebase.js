<script type="module">
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
  import { getAuth } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

  const firebaseConfig = {
    apiKey: "AIzaSyBP2RQEbI78ZzO5qx2XWKkt_ldHXB-sySY",
    authDomain: "vistaroi.firebaseapp.com",
    projectId: "vistaroi",
    storageBucket: "vistaroi.firebasestorage.app",
    messagingSenderId: "21203455228",
    appId: "1:21203455228:web:6b071d89c90442686e1b79"
  };

  const app = initializeApp(firebaseConfig);
  export const auth = getAuth(app);
</script>